class AppConst {
  static const baseUrl = "https://jsonplaceholder.typicode.com";
}