package com.kemsky.git_get

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
